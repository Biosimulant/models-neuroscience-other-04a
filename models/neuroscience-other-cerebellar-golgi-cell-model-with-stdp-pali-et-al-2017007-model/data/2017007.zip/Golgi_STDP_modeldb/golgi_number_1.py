number_ind_1 = dict()
number_ind_1['indiv'] = 8
number_ind_1['morfo_n'] = 1


#fixed list
number_ind_1['pf_syn'] = 20 #89
number_ind_1['mf_syn'] = 0  #20

number_ind_1['aa_syn'] = 0 #20
number_ind_1['inib_syn'] = 0 #20
