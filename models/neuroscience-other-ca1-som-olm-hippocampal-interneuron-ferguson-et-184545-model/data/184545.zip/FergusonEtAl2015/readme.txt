This is the readme for the brian model associated with the paper:

Ferguson KA, Huh CY, Amilhon B, Manseau F, Williams S, Skinner FK
(2015) Network models provide insights into how
oriens-lacunosum-moleculare and bistratified cell interactions
influence the power of local hippocampal CA1 theta oscillations. Front
Syst Neurosci 9:110

This code was contributed by Dr F Skinner.

After brian is installed the model can be started with a command like
python OLM_cell.py
