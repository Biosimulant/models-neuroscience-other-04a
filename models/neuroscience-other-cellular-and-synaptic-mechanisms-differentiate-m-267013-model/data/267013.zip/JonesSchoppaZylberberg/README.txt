Prior to executing these files, download and compile the mod files available on ModelDB from: 

Bhalla US and Bower JM. (1993) Exploring parameter space in detailed single
neuron models: simulations of the mitral and granule cells of the olfactory bulb. 
J. Neurophysiol. 69:1948-1965. 

Running the model (by executing the .hoc files herein) runs a simulation comparable
to each specified figure.

For more information on this work contact nathan.schoppa@cuanschutz.edu
