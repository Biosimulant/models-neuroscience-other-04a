NEURON mod files from the paper:
The membrane response of hippocampal CA3b pyramidal neurons near rest: 
heterogeneity of passive properties and the contribution of hyperpolarization-activated 
currents, by P. Hemond, M. Migliore, GA Ascoli, and DB Jaffe, Neuroscience, in press (2009).

The simulation file can be used to generate the raw data for the bottom plot in Fig.8b,
showing the normalized peak somatic summation, with or without Ih, in response 
to a train of EPSPs at 50Hz

Questions on how to use this model
should be directed to michele.migliore@pa.ibf.cnr.it


