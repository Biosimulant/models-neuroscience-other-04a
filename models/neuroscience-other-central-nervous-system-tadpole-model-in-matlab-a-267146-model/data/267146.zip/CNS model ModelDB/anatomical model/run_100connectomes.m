for i=1:201
    main_spinal_cord_long_sub(i)
end