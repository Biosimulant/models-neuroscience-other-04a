load datastore/casrimax.dat 
load datastore/distances.dat  
load datastore/synweight.dat  
load datastore/vsynmax.dat
plotscalingresults_pergroup1(casrimax,distances,synweight,[])