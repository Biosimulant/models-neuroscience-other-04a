This directory contains dataproduced by the batch script bpap-sims.hoc
