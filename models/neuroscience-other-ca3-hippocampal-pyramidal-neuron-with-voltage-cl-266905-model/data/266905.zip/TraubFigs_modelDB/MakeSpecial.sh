#!/bin/bash
# this shell script creates the special executable version of Neuron
# found at "./x86_64/special"

nrnivmodl ./mods
